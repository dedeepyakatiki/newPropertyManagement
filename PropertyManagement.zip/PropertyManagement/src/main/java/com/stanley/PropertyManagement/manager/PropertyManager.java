package com.stanley.PropertyManagement.manager;

import java.io.IOException;
import java.util.List;

import com.stanley.PropertyManagement.domain.Property;

public interface PropertyManager {
	
	public String addProperty(Property property);
	
	public List<Property> displayProperties() throws IOException;

	

	public List<Property> displayTitles(Property property);

	


}