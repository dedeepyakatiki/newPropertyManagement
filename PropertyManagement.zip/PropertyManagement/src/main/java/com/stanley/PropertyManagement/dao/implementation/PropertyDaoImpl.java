package com.stanley.PropertyManagement.dao.implementation;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;

import com.stanley.PropertyManagement.dao.PropertyDao;
import com.stanley.PropertyManagement.domain.Property;

public class PropertyDaoImpl implements PropertyDao {
	public void insertProperty(Connection conn, Property property) throws SQLException {
		String sql = "Insert into Property(title, location, landmark, area, price, image, contactNumber,amenities) values (?,?,?,?,?,?,?,?)";

		PreparedStatement pstm = conn.prepareStatement(sql);

		pstm.setString(1, property.getTitle());
		pstm.setString(2, property.getLocation());
		pstm.setString(3, property.getLandmark());
		pstm.setString(4, property.getArea());
		pstm.setString(5, property.getPrice());
		pstm.setString(7,property.getContactNumber());
		pstm.setString(8, "");
		String[] amenities = property.getAmenities();
		String a = String.join(",",amenities);
		
		
		pstm.setString(8, a);
		
		
		File i= new File(property.getImage());
		FileInputStream fis = null;
		try {
		fis = new FileInputStream(i);
		} catch (FileNotFoundException e) {
		e.printStackTrace();
		}
		pstm.setBinaryStream(6,(InputStream) fis, (int)(i.length()));
		pstm.executeUpdate();
		}

	
	public List<Property> displayProperty(Connection conn) throws SQLException, IOException {
		
		Blob image = null;
		byte[ ] imgData = null ;
		Statement st = conn.createStatement();
		ResultSet rs = st.executeQuery("Select * from Property");
		List<Property> prop = new ArrayList<Property>();
		while (rs.next()) {
			Property tempProp = new Property();

			tempProp.setId(Integer.parseInt(rs.getString("id")));
			tempProp.setTitle(rs.getString("title"));
			tempProp.setLocation(rs.getString("location"));
			tempProp.setLandmark(rs.getString("landmark"));
			tempProp.setArea(rs.getString("area"));
			tempProp.setPrice(rs.getString("price"));
//			tempProp.setImage(rs.getString("image"));
            tempProp.setContactNumber(rs.getString("contactNumber"));
           
            String[] amenities;
            if (rs.getString("amenities") != null) {
            amenities = rs.getString("amenities").split(",");
            } else {
            amenities = null;
            }
            tempProp.setAmenities(amenities);
            
            Blob blob = rs.getBlob("image");
            InputStream inputStream = blob.getBinaryStream();
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            byte[] buffer = new byte[4096];
            int bytesRead = -1;
            
            while((bytesRead = inputStream.read(buffer)) != -1) {
            	byteArrayOutputStream.write(buffer, 0, bytesRead);
            }
            
            byte[] imageBytes = byteArrayOutputStream.toByteArray();
            String base64Image = Base64.getEncoder().encodeToString(imageBytes);
//            image = rs.getBlob("image");
//            imgData = image.getBytes(1, (int)image.length());
//			prop.add(tempProp);
            inputStream.close();
            byteArrayOutputStream.close();
            tempProp.setImage(base64Image);
            prop.add(tempProp);
		}
		return prop;
	}


	public List<Property> displayTitle(Connection conn,Property property) throws SQLException, IOException {
		
		Blob image = null;
		byte[ ] imgData = null ;
		Statement st = conn.createStatement();
		ResultSet rs = st.executeQuery("Select * from Property where title = '" + property.getTitle() + "';");
		List<Property> prop = new ArrayList<Property>();
		while (rs.next()) {
			Property tempProp = new Property();

			tempProp.setId(Integer.parseInt(rs.getString("id")));
			tempProp.setTitle(rs.getString("title"));
			tempProp.setLocation(rs.getString("location"));
			tempProp.setLandmark(rs.getString("landmark"));
			tempProp.setArea(rs.getString("area"));
			tempProp.setPrice(rs.getString("price"));
			tempProp.setContactNumber(rs.getString("contactNumber"));
	            
	            Blob blob = rs.getBlob("image");
	            InputStream inputStream = blob.getBinaryStream();
	            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
	            byte[] buffer = new byte[4096];
	            int bytesRead = -1;
	            
	            while((bytesRead = inputStream.read(buffer)) != -1) {
	            	byteArrayOutputStream.write(buffer, 0, bytesRead);
		}
	            
	            byte[] imageBytes = byteArrayOutputStream.toByteArray();
	            String base64Image = Base64.getEncoder().encodeToString(imageBytes);
	            inputStream.close();
	            byteArrayOutputStream.close();
	            tempProp.setImage(base64Image);
	            prop.add(tempProp);
		}
		return prop;
	}
}