package com.stanley.PropertyManagement.servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.stanley.PropertyManagement.domain.Property;
import com.stanley.PropertyManagement.manager.PropertyManager;
import com.stanley.PropertyManagement.manager.implementation.PropertyManagerImpl;

@WebServlet(urlPatterns = { "/SearchProperty" })
public class SearchProperty extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String title = (String) request.getParameter("Search");

		Property property = new Property(title);

		List<Property> properties = new ArrayList<Property>();

		PropertyManager prop = new PropertyManagerImpl();
		properties = prop.displayTitles(property);
		request.setAttribute("properties", properties);

		request.getRequestDispatcher("/ViewProperties.jsp").forward(request, response);
	}

}